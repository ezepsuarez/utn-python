edad_jubilacion=65

edad=int(input("Ingrese su edad: "))

if edad >= edad_jubilacion:
    print ("Esta en edad de jubilarse")
else:
    print ("Aun debe continuar trabajando")