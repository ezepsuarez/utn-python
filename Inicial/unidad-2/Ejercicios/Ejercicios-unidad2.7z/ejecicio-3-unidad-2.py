auto1=input("Ingrese la marca del auto 1: ")
auto2=input("Ingrese la marca del auto 2: ")

lista_autos=[auto1, auto2]
print ("la lista de autos es: ", lista_autos)