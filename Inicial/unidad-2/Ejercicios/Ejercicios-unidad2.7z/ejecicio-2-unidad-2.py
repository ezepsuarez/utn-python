frutas = ["pera", "manzana"]
print ("la ", frutas[0] ,"y la", frutas[1], "son frutas de estacion.")
