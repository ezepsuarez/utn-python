mi_variable = 1
mi_variable2 = "Pera"
mi_lista = [
    mi_variable,
    mi_variable2,
    1.2,
    "Limón",
]
print(mi_lista)
print(mi_lista[2], " --- ", mi_lista[-2])
autos = ["auto1", "auto2"]

resultado = mi_lista + autos
print(resultado)
