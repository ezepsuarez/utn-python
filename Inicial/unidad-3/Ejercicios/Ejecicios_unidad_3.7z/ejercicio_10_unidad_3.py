clave="holaMundo"
entrada=input("Ingrese su clave:")

while clave != entrada:
    print("Su clave es incorrecta.")
    entrada=input("Ingrese su clave:")

print ("Su clave es correcta")