def sumar(a, b):
    c = a + b
    return c 

def multiplicar(a, b):
    c = a * b
    return c 