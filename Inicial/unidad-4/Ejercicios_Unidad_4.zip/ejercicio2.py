"""
Crear una función lambda que sea equivalente a la siguiente función:
def multiplicar_por_tres(valor):
    res = 3 * valor
    return res
"""

multiplicar_por_tres = lambda v : v * 3

valor = int(input('Ingrese un valor: '))

print(f'El valor {valor} multiplicado por 3 es: {multiplicar_por_tres(valor)}')