"""
Cree una función que tome la siguiente lista y reordene de menor a mayor sus componentes:
[3, 44, 21, 78, 5, 56, 9] 
"""

lista = [3, 44, 21, 78, 5, 56, 9]

def ordenar(lista, indice, mayor):
    if len(lista) == indice:
        return lista
    elif mayor > lista[indice]:
        lista[indice - 1] = lista[indice]
        lista[indice] = mayor
        mayor = lista[0]
        indice = 0
    else:
        mayor = lista[indice]

    return ordenar(lista, (indice + 1), mayor)

print(f'La lista ordenada de menor a mayor es: {ordenar(lista, 0, 0)}')
