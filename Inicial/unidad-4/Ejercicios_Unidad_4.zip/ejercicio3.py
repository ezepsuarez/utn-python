"""
Crear una función lambda que sea equivalente a la siguiente función: 
def sumar(valor1, valor2):
    res = valor1 + valor2
    return res
"""

sumar = lambda v1, v2 : v1 + v2

valor1 = int(input('Ingrese el primer valor: '))
valor2 = int(input('Ingrese el segundo valor: '))

print(f'La suma de {valor1} + {valor2} es: {sumar(valor1, valor2)}')