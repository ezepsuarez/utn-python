"""
Crear una función lambda que tome como parámetro una frase y la escriba al revés.
"""

invertir = lambda f : f[len(f)::-1]

frase = input('Ingrese la frase que desea invertir: ')

print(f'La frase invertida es {invertir(frase)}')