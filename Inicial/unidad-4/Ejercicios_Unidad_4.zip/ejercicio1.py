"""
Cree una función lamba que compruebe si un número es par o impar.
"""

func = lambda num : f'El numero {num} es par' if num % 2 == 0 else f'El numero {num} es impar'

valor = int(input('Ingrese el numero que desea saber si es par o impar: '))

print(func(valor))