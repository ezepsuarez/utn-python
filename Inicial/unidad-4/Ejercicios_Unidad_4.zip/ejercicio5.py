"""
Cree un programa que utilizando una función, solicite la edad de la persona
e imprima todos los años que la persona ha cumplido según el siguiente formato de ejemplo
1, 2, 3, 4, 5
Y
5, 4, 3, 2, 1
"""

x = 1

edad = int(input('Ingrese la edad de la persona: '))

def mostrar_edad(x, edad, asc):
    if x == edad:
        return edad
    else:
        return f'{x}, {mostrar_edad(x+1, edad, True)}' if asc else f'{x}, {mostrar_edad(x-1, edad, False)}'


print(f'Años que la persona cumplio (ascendente): {mostrar_edad(x,edad,True)}')
print(f'Años que la persona cumplio (descendente): {mostrar_edad(edad,x,False)}')