#Invertir o poner al revés una cadena de caracteres función no lambda:

def texto_invertido(texto) :
    return ''.join(reversed(texto))

print(texto_invertido('Hola cómo estás?'))

#Versión Lambda

res = lambda frase : ''.join(reversed(frase))

print(res('Hola cómo estás?'))