lista1 = [3, 44, 21, 78, 5, 56, 9]

def ordenar_lista(lista) :
    lista_ordenada = sorted(lista)
    return lista_ordenada

print(ordenar_lista(lista1))