res = lambda valor1, valor2 : valor1 + valor2

print(res(3,48))