
def years_cumplidos() :

    edad = int(input('Ingrese su edad: '))
    
    contador = 0
    
    while contador <= edad :
        edad_final = edad - contador
        print(str(edad_final), end=",")
        contador += 1
    
    contador2 = edad
    
    while contador2 >= 0 :
        edad_final2 = edad - contador2
        print(str(edad_final2), end=",")
        contador2 -= 1


years_cumplidos()