res = lambda valor : valor * 3

print(res(10))