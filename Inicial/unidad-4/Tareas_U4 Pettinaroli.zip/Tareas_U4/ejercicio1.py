par_impar = lambda numero : numero % 2 

print("Si el número es par el resultado será 0 y si es impar será 1: ", par_impar(5))