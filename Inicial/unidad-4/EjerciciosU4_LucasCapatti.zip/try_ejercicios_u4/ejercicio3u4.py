# Crear funcion lambda equivalente a "def sumar(valor1, valor2)"

sumar = lambda num1, num2: num1 + num2

print(sumar(1, 2))  # 3
print(sumar(3, 4))  # 7
