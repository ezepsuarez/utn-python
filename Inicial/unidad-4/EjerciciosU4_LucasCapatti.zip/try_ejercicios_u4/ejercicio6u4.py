def metodo_de_burbuja(lista):
    tamano = len(lista)
    for _ in range(0, tamano):
        for j in range(0, tamano - 1):
            if lista[j] > lista[j + 1]:
                aux = lista[j]
                lista[j] = lista[j + 1]
                lista[j + 1] = aux


def ordenar(list):
    return list.sort()


lista = [3, 44, 21, 78, 5, 56, 9]
lista2 = [3, 44, 21, 78, 5, 56, 9]

print(lista)
metodo_de_burbuja(lista)
print(lista)

print()

print(lista2)
ordenar(lista2)
print(lista2)
