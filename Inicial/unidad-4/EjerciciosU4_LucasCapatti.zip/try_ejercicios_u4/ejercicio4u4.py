# Crear una función lambda que tome como parámetro una frase y la escriba al revés.
frase = (
    "Si siempre llegas a tiempo, eso significa que nunca tienes nada mejor que hacer."
)
voltear = lambda str: str[len(str) :: -1]
reverso = lambda str: "".join(reversed(str))

print(voltear(frase))
print()
print(reverso(frase))
