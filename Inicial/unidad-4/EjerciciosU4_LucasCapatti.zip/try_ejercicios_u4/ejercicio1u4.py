# Cree una función lamba que compruebe si un número es par o impar.

impar = lambda num: num % 2 != 0
print(impar(3))  # True
print(impar(2))  # False
