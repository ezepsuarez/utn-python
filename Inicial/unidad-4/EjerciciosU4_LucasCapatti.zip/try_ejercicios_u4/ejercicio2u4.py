# Crear funcion lambda equivalente a "def mutiplicar por tres"

por_tres = lambda num: num * 3
print(por_tres(3))  # 9
print(por_tres(2))  # 6
