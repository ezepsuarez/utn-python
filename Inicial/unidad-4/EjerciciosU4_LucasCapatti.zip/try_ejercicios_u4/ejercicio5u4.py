# Cree un programa que utilizando una función, solicite la edad de la persona e imprima todos los años que la persona ha cumplido según el siguiente formato de ejemplo.


def contador(n):
    if n != 0:
        contador(n - 1)
    print(n)


def cont_invert(k):
    print(k)

    if k > 0:
        cont_invert(k - 1)


edad = int(input("ingrese su edad: "))

contador(edad)
print()
cont_invert(edad)
