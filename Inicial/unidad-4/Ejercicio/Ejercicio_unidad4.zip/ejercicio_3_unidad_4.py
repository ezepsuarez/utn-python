numero = lambda numero1,numero2: numero1 +numero2 

numero1=int(input("Ingrese el valor 1: "))
numero2=int(input("Ingrese el valor 2: "))

print(f" Resultado es: ", numero(numero1, numero2))