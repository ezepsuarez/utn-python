numero = lambda num: num % 2 == 0
print(f" Resultado es: ", numero(int(input("Ingrese un numero: "))))