muestra_oracion = lambda oracion: oracion[::-1]
oracion=input("Ingrese una frase: ")

print(f" La frase ingresada es:", oracion)
print(f" La frase al reves es: ", muestra_oracion(oracion))