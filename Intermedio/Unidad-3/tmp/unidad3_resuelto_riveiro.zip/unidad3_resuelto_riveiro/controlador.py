""" Autor: Daniel Riveiro
Fecha: 30/10/2022
Curso - Python 3 - Nivel Intermedio (999188621)
Nombre: Resuelto unidad 3, módulo 1 
Programa: aplicar lo aprendido en esta unidad pasando el código de su trabajo a POO."""


from tkinter import Tk
from vista import *


if __name__ == "__main__":
    ventana = Tk()
    stock.vista_principal(ventana)
    ventana.mainloop()
