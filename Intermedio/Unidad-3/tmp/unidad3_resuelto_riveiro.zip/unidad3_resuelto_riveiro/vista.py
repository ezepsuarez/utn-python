""" Autor: Daniel Riveiro
Fecha: 30/10/2022
Curso - Python 3 - Nivel Intermedio (999188621)
Nombre: Resuelto unidad 3, módulo 1 
Programa: aplicar lo aprendido en esta unidad pasando el código de su trabajo a POO."""


from tkinter import StringVar
from tkinter import DoubleVar
from tkinter import Label
from tkinter import Entry
from tkinter import ttk
from tkinter import Tk
from tkinter import Button
from tkinter import Scrollbar

from modelo import *

class MiVentana():
    def vista_principal(self, ventana):

        base_datos.crear_base()

        # Inicio de la ventana.
        ventana.wm_title("Control de stock comercial")

        # Las categorias

        producto = ttk.Label(ventana, text="Producto").grid(column=0, row=1)

        cantidad = ttk.Label(ventana, text="Cantidad").grid(column=2, row=0)

        precio = ttk.Label(ventana, text="Precio").grid(column=2, row=1)

        # Espacios para entrada de datos:

        producto_entrada = StringVar()
        producto = Entry(ventana, textvariable=producto_entrada).grid(
            column=1, row=1)

        producto_entrada = StringVar()
        producto = Entry(ventana, textvariable=producto_entrada).grid(
            column=1, row=1)

        cantidad_entrada = StringVar()
        cantidad = Entry(
            ventana, textvariable=cantidad_entrada).grid(column=3, row=0)

        precio_entrada = StringVar()
        entr_03 = Entry(ventana, textvariable=precio_entrada).grid(column=3, row=1)

        # treeview de la información:

        tree = ttk.Treeview(ventana)
        tree["columns"] = ("col1", "col2", "col3")
        tree.column("#0", width=90, minwidth=50, anchor="w")
        tree.column("col1", width=145, minwidth=100)
        tree.column("col2", width=145, minwidth=100)
        tree.column("col3", width=100, minwidth=100)
        tree.heading("#0", text="ID")
        tree.heading("col1", text="Producto")
        tree.heading("col2", text="Cantidad")
        tree.heading("col3", text="Precio")
        tree.grid(column=0, columnspan=5)

        # barra para el scroll

        scroll = Scrollbar(ventana)
        scroll.grid(row=1, column=4, rowspan=4)

        tree.configure(yscrollcommand=scroll.set)
        scroll.configure(command=tree.yview)

        # Los botones:
        boton1 = ttk.Button(ventana, text="Añadir Producto",
                            width=25, command=lambda: ingresar.alta_datos(producto_entrada.get(),
                                                                cantidad_entrada.get(), precio_entrada.get(), tree, producto_entrada.set(""), precio_entrada.set(0), cantidad_entrada.set(0))).grid(column=1, row=3)

        boton2 = ttk.Button(ventana, text="Mostrar Todo",
                            width=25, command=lambda: relevar.mostrar_datos(tree)).grid(column=1, row=4)

        boton3 = ttk.Button(ventana, text="Buscar",
                            width=25, command=lambda: relevar.consultar_datos(tree, producto_entrada.get(), cantidad_entrada.get(), precio_entrada.get())).grid(column=1, row=5)

        boton4 = ttk.Button(ventana, text="Actualizar Producto",
                            width=25, command=lambda: modificar.actualizar_datos(tree, producto_entrada.get(), cantidad_entrada.get(), precio_entrada.get(), producto_entrada.set(""), precio_entrada.set(0), cantidad_entrada.set(0))).grid(column=3, row=3)

        boton5 = ttk.Button(ventana, text="Borrar Producto",
                            width=25, command=lambda: ingresar.baja_datos(tree)).grid(column=3, row=4)

        boton6 = ttk.Button(ventana, text="Exportar tabla",
                            width=25, command=lambda: expt.exportar_datos()).grid(column=3, row=5)

        boton7 = ttk.Button(ventana, text="Limpiar Pantalla",
                            width=25, command=lambda: relevar.limpiar_pantalla(tree)).grid(column=1, row=6)

        boton8 = ttk.Button(ventana, text="Cerrar", width=25,
                            command=ventana.destroy).grid(column=3, row=6)

        ventana.mainloop()

stock = MiVentana()