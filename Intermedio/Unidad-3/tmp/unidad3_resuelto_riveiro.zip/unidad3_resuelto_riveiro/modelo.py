""" Autor: Daniel Riveiro
Fecha: 30/10/2022
Curso - Python 3 - Nivel Intermedio (999188621)
Nombre: Resuelto unidad 3, módulo 1 
Programa: aplicar lo aprendido en esta unidad pasando el código de su trabajo a POO."""

import os
import sqlite3
import re
import csv
from tkinter import ttk
from tkinter import messagebox


class MiBase():
    def crear_base(self, ):  # Crear base de datos.
        con = sqlite3.connect("base01.db")
        cursor = con.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS inventario_01(id INTEGER PRIMARY KEY AUTOINCREMENT, producto varchar(20) NOT NULL, cantidad REAL, precio REAL)")
        con.commit()
        con.close()

base_datos = MiBase()


class AgregarDato():

    def alta_datos(self, producto, cantidad, precio, tree, a, b, c):
        letras = (r'[a-zA-Z]+')
        con = sqlite3.connect("base01.db")
        cursor = con.cursor()
    # Buscar que el campo producto no quede vacío.
        if len(producto.strip()) == 0:
            messagebox.showerror("Error en producto",
                                "El campo producto no puede quedar vacío")
        # Producto y cantidad no admiten letras.
        elif re.search(letras, cantidad) is None and re.search(letras, precio) is None:
            cursor.execute(
                "INSERT INTO inventario_01 (producto, cantidad, precio) VALUES (?, ?, ?)", (
                    producto, cantidad, precio))
            messagebox.showinfo(
                "Entrada agregada", "La entrada fue agregada con éxito")
        else:
            messagebox.showerror(
                "Error de entrada.", "El campo de cantidad y precio no pueden contener letras.")
        con.commit()
        relevar.mostrar_datos(tree)

    def baja_datos(self, tree):  # esta función borra la entrada seleccionada.
        con = sqlite3.connect("base01.db")
        cursor = con.cursor()
        valor = tree.selection()
        print(valor)
        item = tree.item(valor)
        print(item)
        print(item['text'])
        mi_id = item['text']
        data = (mi_id,)
        sql = "DELETE FROM inventario_01 WHERE id = ?;"
        cursor.execute(sql, data)
        con.commit()
        tree.delete(valor)

ingresar = AgregarDato()

class RelevarDatos():
    
    def mostrar_datos(self, mitreview):  # función para mostrar el contenido de la tabla
        con = sqlite3.connect("base01.db")
        records = mitreview.get_children()
        for element in records:
            mitreview.delete(element)
        cursor = con.cursor()
        cursor.execute("SELECT * FROM inventario_01 ORDER BY id ASC")
        rows = cursor.fetchall()
        for row in rows:
            print(row)
            mitreview.insert("", 0, text=row[0],
                            values=(row[1], row[2], row[3]))
        con.close()

    def limpiar_pantalla(self, mitreview):
        # Con esto se limpia el Treeview para despejar la pantalla.
        records = mitreview.get_children()
        for element in records:
            mitreview.delete(element)

    def consultar_datos(self, tree, producto="", cantidad="", precio=""):
        # Esta función permite buscar datos por nombre de producto, cantidad o precio.
        con = sqlite3.connect("base01.db")
        cursor = con.cursor()
        cursor.execute("SELECT * FROM inventario_01 WHERE producto=? OR cantidad=? OR precio=?",
                    (producto, cantidad, precio))
        rows = cursor.fetchall()
        for row in rows:
            print(row)
            tree.insert("", 0, text=row[0],
                        values=(row[1], row[2], row[3]))
        con.close()

relevar = RelevarDatos()


class ModificarDatos():


    def actualizar_datos(self, tree, producto, cantidad, precio, a, b, c):
        letras = (r'[a-zA-Z]+')
        marcador = tree.selection()
        selected = tree.focus()
        tree.item(selected, values=(producto,
                cantidad, precio))
        item = tree.item(marcador)
        mi_id = item['text']
        con = sqlite3.connect('base01.db')
        cursor = con.cursor()
        print(tree.item(tree.focus()))
        if not producto:
            messagebox.showerror("Campo incompleto",
                                "El campo de producto no puede quedar sin completar")
            relevar.limpiar_pantalla(tree)
        elif re.search(letras, cantidad) is None and re.search(letras, precio) is None:
            cursor.execute("UPDATE inventario_01 SET producto=?, cantidad=?, precio=? WHERE id=? ",
                        (producto, cantidad, precio, mi_id))
        else:
            messagebox.showerror(
                "Error de entrada.", "El campo de cantidad y precio no pueden contener letras.")
            relevar.limpiar_pantalla(tree)
        con.commit()
        con.close()

modificar = ModificarDatos()

class Exportar():

    def exportar_datos(self):
        # Esta función que sigue permite exportar los datos
        # en formato csv, para abrirlo con programas de planilla de cálculo.
        con = sqlite3.connect("base01.db")
        con.text_factory = str
        cur = con.cursor()
        data = cur.execute("SELECT * FROM inventario_01")
        if os.path.exists("inventario_01.csv"):
            messagebox.showerror(
                "¡Cuidado!", "Ya hay un antiguo archivo scv de los datos en esta carpeta. Borralo o movelo a otro lado antes de poder generar uno nuevo. ")
        else:
            with open('inventario_01.csv', 'w') as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Producto", "Cantidad", "Precio"])
                writer.writerows(data)
                messagebox.showinfo(
                    "Tabla exportada", "La información fue exportada correctamente.")
        con.commit()
        con.close()

expt = Exportar()

