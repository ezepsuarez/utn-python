from tkinter import *
from vista import interfaz

if __name__ == "__main__":
    master = Tk()
    interfaz(master)
    master.mainloop()