import random 
numero = random.randint(-5, 5)