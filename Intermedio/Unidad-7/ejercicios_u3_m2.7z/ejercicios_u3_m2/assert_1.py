from para_calcular_raiz import numero
print(numero)
assert numero >=0 , "El valor debe ser mayor o igual a cero"
print(numero**0.5)