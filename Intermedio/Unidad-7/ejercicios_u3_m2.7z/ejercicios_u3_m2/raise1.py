x = -1

if x < 0:
    raise Exception("Valor no permitido")
