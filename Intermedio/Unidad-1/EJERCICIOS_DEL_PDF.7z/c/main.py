from modulo3 import x, y

x = 42     # cambia solo esta x no la del módulo importado
y[0] = 84
print(x)
print(y[0])
print(y)
from modulo3 import x, y
print(x)
print(y[0])
print(y)