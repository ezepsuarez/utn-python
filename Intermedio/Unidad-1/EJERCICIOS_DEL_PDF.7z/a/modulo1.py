def imprimir(mensaje):
    print(mensaje)