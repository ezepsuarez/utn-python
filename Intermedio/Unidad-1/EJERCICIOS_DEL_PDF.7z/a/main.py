import modulo1
import sys
print(sys.path)

modulo1.imprimir('Mensaje a imprimir')
print(sys.modules)
