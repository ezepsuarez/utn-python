X = 11
Y = 11
import modulo6
modulo6.f()
print(X, modulo6.X)
modulo6.g(1)
print(Y, modulo6.Y)



