X = 88
Y = 88

def f():
    global X
    X = 99

def g(Z):
    global Y
    Y = Y + Z





