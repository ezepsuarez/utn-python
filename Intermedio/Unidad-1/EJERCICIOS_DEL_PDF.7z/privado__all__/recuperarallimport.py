import privadoall

print(privadoall.variablePrivada1)


