import modulo5

print(list(modulo5.__dict__.keys()))

print( modulo5.__dict__['__file__'])
print( modulo5.__dict__['__name__'])


