print('Hola')

nombre = 'Juan'

def funcion1():pass


class Clase1(): pass

print('Chau')




