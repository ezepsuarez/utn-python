import modulo4

modulo4.x = 42             # cambia el valor de la x del módulo.
print(modulo4.x)

import modulo4
print(modulo4.x)
from modulo4 import x
print(x)
