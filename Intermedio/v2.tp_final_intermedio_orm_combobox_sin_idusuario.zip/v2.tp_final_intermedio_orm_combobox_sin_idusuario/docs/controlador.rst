controlador module
==================

.. automodule:: controlador
   :members:
   :undoc-members:
   :show-inheritance:
