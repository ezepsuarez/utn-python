.. MiApp-Nivel-Intermedio documentation master file, created by
   sphinx-quickstart on Wed Nov 30 13:47:22 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MiApp-Nivel-Intermedio's documentation!
==================================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   controlador
   modelo
   vista


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
