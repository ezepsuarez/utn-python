vista module
============

.. automodule:: vista
   :members:
   :undoc-members:
   :show-inheritance:
